export const LIMIT = 20;
export const UPLOAD_CONST = "https://dermapuritys.com/php/upload1.php";
