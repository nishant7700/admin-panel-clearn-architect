import React from "react";

function About() {
  return (
    <div>
      <h1> About Us </h1>
    </div>
  );
}

export default About;
