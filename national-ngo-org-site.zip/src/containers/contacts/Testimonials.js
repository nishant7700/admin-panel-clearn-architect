import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import Header from '../../components/template/Header'
import Footer from '../../components/template/Footer'
import BreadCrumb from '../../components/template/BreadCrumb'
import { Link } from 'react-router-dom'
import renderHTML from 'react-render-html'
import {
  getTestimonials,
  getNextTestimonials,
  getPreviousTestimonials,
} from '../../store/actions/testimonials_action'
import { LIMIT } from '../../domain/constant'
import Pagination from '../../components/common/Pagination'
import Spinner from '../../components/layout/Spinner'
function Testimonials({
  getTestimonials,

  getNextTestimonials,
  getPreviousTestimonials,
  testimonial: { loading, testimonials },
}) {
  const [page, setPage] = useState(1)
  useEffect(() => {
    async function allQuery() {
      getTestimonials({})
    }
    allQuery()
  }, [])
  const nextButtonClicked = () => {
    if (testimonials && testimonials.length === LIMIT) {
      const lastTestimonial = testimonials[testimonials.length - 1]
      getNextTestimonials({ last: lastTestimonial })
      setPage(page + 1)
    }
  }
  const prevBtnClicked = () => {
    if (page > 1) {
      const lastTestimonial = testimonials[0]
      getPreviousTestimonials({
        first: lastTestimonial,
      })
      setPage(page - 1)
    }
  }
  return (
    <div>
      <Header active="HOME" />
      <BreadCrumb title={'Testimonials'} />
      {!loading ? (
        <section className="current ptb-50">
          <div className="container">
            <div className="current-project">
              <div className="row">
                {testimonials &&
                  testimonials.map((item) => {
                    return (
                      <div className="col-md-12">
                        <div>
                          <div className="main-testi-flex ">
                            <div className>
                              <img
                                src={
                                  item.featured_image
                                    ? item.featured_image
                                    : '/assets/images/default.jpg'
                                }
                                className="testimonial-pic"
                              />
                            </div>
                            <div className="testimonial-content">
                              <h3>{item.name}</h3>
                              <p>{item.testimonial}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
              </div>
            </div>
          </div>
        </section>
      ) : (
        <div>
          <Spinner />
        </div>
      )}
      <section className="ptb-50">
        <Pagination
          data={testimonials}
          page={page}
          prevBtnClicked={prevBtnClicked}
          nextButtonClicked={nextButtonClicked}
          loading={loading}
        />
      </section>
      <Footer />
    </div>
  )
}
const mapStateToProps = (state) => ({ testimonial: state.testimonial })

const mapDispatchToProps = {
  getTestimonials,
  getNextTestimonials,
  getPreviousTestimonials,
}

export default connect(mapStateToProps, mapDispatchToProps)(Testimonials)
