import React from "react";
import Spinner from "../layout/Spinner";
import Slider from "react-slick";
import { Link } from "react-router-dom";
import renderHTML from "react-render-html";

function HomepageCurrentBeneficiaries({ causes, loading }) {
  var settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <>
      {!loading ? (
        <section className="current ptb-50">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="sec-heading">
                  <h2>Current Beneficiaries</h2>
                </div>
              </div>
            </div>
            <div className="current-project">
              <div>
                <Slider {...settings}>
                  {causes &&
                    causes.map((item) => {
                      return (
                        <div>
                          <div className="inner-box">
                            <img
                              src={
                                item.featured_image
                                  ? item.featured_image
                                  : "/assets/images/default.jpg"
                              }
                              className="profile"
                            />
                            <div className="box-content">
                              <div className="project-heading">
                                <h3>{item.name}</h3>
                              </div>
                              <p className="medical-documents">
                                {" "}
                                Medical Documents{" "}
                              </p>
                              <hr />
                              <p className="disease">
                                <strong>
                                  <i className="fa fa-ambulance"> </i>{" "}
                                  {item.disease}
                                </strong>
                              </p>
                              <hr />
                              <div className="story">
                                {item.content && renderHTML(item.content)}
                              </div>

                              <hr />
                            </div>
                            <div className="btn-flex">
                              <div className>
                                <a href="#" className="btn btn-donate-project">
                                  <i className="fa fa-heart" /> DONATE US
                                </a>
                              </div>
                              <div className>
                                <a href="#" className="btn btn-view-details">
                                  <i className="fa fa-facebook" />
                                </a>
                                <a href="#" className="btn btn-wa-details">
                                  <i className="fa fa-whatsapp" />
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </Slider>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <div>
          <Spinner />
        </div>
      )}
    </>
  );
}

export default HomepageCurrentBeneficiaries;
