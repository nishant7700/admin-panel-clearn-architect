import React from "react";
import Spinner from "../layout/Spinner";
import Slider from "react-slick";
import { Link } from "react-router-dom";
function HomepageStories({ stories, loading }) {
  var settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 3,
  };
  return (
    <>
      {!loading ? (
        <section className="current ptb-50">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="sec-heading">
                  <h2>Successful Stories</h2>
                </div>
              </div>
            </div>
            <div className="current-project">
              <div>
                <Slider {...settings}>
                  {stories &&
                    stories.map((item) => {
                      return (
                        <div>
                          <Link to={`/success-stories/${item.slug}`}>
                            <div className="inner-box">
                              <img
                                src={
                                  item.image
                                    ? item.image
                                    : "/assets/images/default.jpg"
                                }
                                className="profile"
                              />
                              <div className="box-content">
                                <div className="project-heading">
                                  <h3>{item.name}</h3>
                                </div>
                                <p className="medical-documents">
                                  {" "}
                                  Medical Documents{" "}
                                </p>
                                <hr />
                                <p className="disease">
                                  <strong>
                                    <i className="fa fa-ambulance"> </i>{" "}
                                    {item.disease}
                                  </strong>
                                </p>
                                <hr />
                                {item.money_spent && (
                                  <div className="box-content-flex">
                                    <div className>
                                      <h5>Money Spent</h5>
                                    </div>
                                    <div className="bor" />
                                    <div className="bor" />
                                    <div className>
                                      <h5>₹{item.money_spent}</h5>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </Link>
                        </div>
                      );
                    })}
                </Slider>
              </div>
            </div>
          </div>
          <div className="mt-5">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <div className="text-center">
                    <Link to={`/success-stories`} className="btn btn-donate-lg">
                      {" "}
                      View All{" "}
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <div>
          <Spinner />
        </div>
      )}
    </>
  );
}

export default HomepageStories;
