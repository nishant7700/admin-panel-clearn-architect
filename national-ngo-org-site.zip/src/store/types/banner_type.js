export const GET_BANNERS = "GET_BANNERS";
export const FILTER_BANNERS = "FILTER_BANNERS";
export const ADD_BANNER = "ADD_BANNER";
export const EDIT_BANNER = "EDIT_BANNER";
export const GET_BANNER = "GET_BANNER";
export const RESET_BANNER = "RESET_BANNER";
export const BANNERS_ERROR = "BANNERS_ERROR";
