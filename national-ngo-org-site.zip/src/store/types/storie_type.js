export const GET_STORIES = "GET_STORIES";
export const FILTER_STORIES = "FILTER_STORIES";
export const ADD_STORIE = "ADD_STORIE";
export const EDIT_STORIE = "EDIT_STORIE";
export const GET_STORIE = "GET_STORIE";
export const RESET_STORIE = "RESET_STORIE";
export const STORIES_ERROR = "STORIES_ERROR";
