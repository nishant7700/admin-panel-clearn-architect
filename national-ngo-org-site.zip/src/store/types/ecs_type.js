export const GET_ECSS = "GET_ECSS";
export const FILTER_ECSS = "FILTER_ECSS";
export const ADD_ECS = "ADD_ECS";
export const EDIT_ECS = "EDIT_ECS";
export const GET_ECS = "GET_ECS";
export const RESET_ECS = "RESET_ECS";
export const ECSS_ERROR = "ECSS_ERROR";
