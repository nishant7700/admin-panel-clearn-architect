export const GET_MOBILES = "GET_MOBILES";
export const FILTER_MOBILES = "FILTER_MOBILES";
export const ADD_MOBILE = "ADD_MOBILE";
export const EDIT_MOBILE = "EDIT_MOBILE";
export const GET_MOBILE = "GET_MOBILE";
export const RESET_MOBILE = "RESET_MOBILE";
export const MOBILES_ERROR = "MOBILES_ERROR";
