export const GET_CAUSES = "GET_CAUSES";
export const FILTER_CAUSES = "FILTER_CAUSES";
export const ADD_CAUSE = "ADD_CAUSE";
export const EDIT_CAUSE = "EDIT_CAUSE";
export const GET_CAUSE = "GET_CAUSE";
export const RESET_CAUSE = "RESET_CAUSE";
export const CAUSES_ERROR = "CAUSES_ERROR";
