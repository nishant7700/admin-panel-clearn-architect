export const GET_EVENTS = "GET_EVENTS";
export const FILTER_EVENTS = "FILTER_EVENTS";
export const ADD_EVENT = "ADD_EVENT";
export const EDIT_EVENT = "EDIT_EVENT";
export const GET_EVENT = "GET_EVENT";
export const RESET_EVENT = "RESET_EVENT";
export const EVENTS_ERROR = "EVENTS_ERROR";
