export const GET_BLOGS = "GET_BLOGS";
export const FILTER_BLOGS = "FILTER_BLOGS";
export const ADD_BLOG = "ADD_BLOG";
export const EDIT_BLOG = "EDIT_BLOG";
export const GET_BLOG = "GET_BLOG";
export const RESET_BLOG = "RESET_BLOG";
export const BLOGS_ERROR = "BLOGS_ERROR";
