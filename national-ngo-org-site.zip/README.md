# Clean Architecture Code for Admin Panal

Using Firebase and firestore with upload on server
